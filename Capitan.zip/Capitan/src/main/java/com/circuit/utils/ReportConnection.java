/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.circuit.utils;

/**
 *
 * @author Marvin
 */
public class ReportConnection {
    
    public static final String REPORT_LOCATION = System.getProperty("REPORT_LOCATION");
    public static final String CLEARANCE_REPORT = "bgyclearance_report.jasper";
    public static final String CLEARANCE_RECIEPT = "bgyclearance_report_reciept.jasper";
    public static final String BUS_CLEARANCE_REPORT = "busclearance_report.jaseper";
    
}
