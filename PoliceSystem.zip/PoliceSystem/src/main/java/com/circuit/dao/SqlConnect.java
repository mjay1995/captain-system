/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.circuit.dao;

import javax.sql.DataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 *
 * @author Marvin
 */
@Configuration
@ComponentScan(basePackageClasses = DatabaseDao.class)
public class SqlConnect {
    
     @Bean(name="DataSource")
    
    public DataSource getDataSource()
    {
        DriverManagerDataSource dm = new DriverManagerDataSource();
        dm.setDriverClassName("org.sqlite.JDBC");
        dm.setUrl("jdbc:sqlite:" + System.getProperty("DB_LOCATION"));
        return dm;
    
}
    
}
