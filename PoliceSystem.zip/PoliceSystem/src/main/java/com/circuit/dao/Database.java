/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.circuit.dao;

import com.circuit.exception.ServiceException;
import com.circuit.obj.Barangay;
import com.circuit.obj.BarangayPolice;
import java.util.List;

/**
 *
 * @author Marvin
 */
public interface Database {
    
    public BarangayPolice getProfileId(int id) throws ServiceException;
    
    public List<BarangayPolice> getAllPoliceRecords() throws ServiceException;
    
    public BarangayPolice saveRecords(BarangayPolice barangayPolice) throws ServiceException;
 
    public boolean removeRecords(BarangayPolice barangayPolice) throws ServiceException;
    

}
