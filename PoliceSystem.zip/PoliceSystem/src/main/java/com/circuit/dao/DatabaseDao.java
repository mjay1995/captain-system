/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.circuit.dao;

import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Marvin
 */
@Repository
public class DatabaseDao {
    
    public DataSource dataSource = new SqlConnect().getDataSource();
    
    @Autowired
	public void setDataSource(DataSource dataSource) throws SQLException{
		this.dataSource = dataSource;
	}

	/**
	 * Gets the connection.
	 *
	 * @return the connection
	 * @throws SQLException the SQL exception
	 */
	public Connection getConnection() throws  SQLException {
		return this.dataSource.getConnection();
	}
    
}
