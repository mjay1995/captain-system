/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.circuit.dao;

import com.circuit.exception.ServiceException;
import com.circuit.obj.BarangayPolice;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.ValidationException;

/**
 *
 * @author Marvin
 */
    public class DataImplement extends DatabaseDao implements Database {

    @Override
    public BarangayPolice getProfileId(int id) throws ServiceException {
        BarangayPolice barangayPolice = new BarangayPolice();
        PreparedStatement preparedStatement;
        try
        {
            String getProfile = ""
                    + "SELECT * FROM"
                    + "police_records_tb"
                    + "WHERE id = ?";
            preparedStatement = this.getConnection().prepareStatement(getProfile);
            preparedStatement.setInt(1, id);
            preparedStatement.execute();
            ResultSet resultSet = preparedStatement.getResultSet();
            while(resultSet.next())
            {
                barangayPolice.setId(resultSet.getInt("id"));
                if(resultSet.getString("new") == "1")
                {
                    barangayPolice.setForNew(true);
                }
                else
                {
                    barangayPolice.setForOld(true);
                }
                
                barangayPolice.setFIRST_NAME(resultSet.getString("first_name"));
                barangayPolice.setLAST_NAME(resultSet.getString("last_name"));
                barangayPolice.setMIDDLE_NAME(resultSet.getString("middle_initial"));
                barangayPolice.setBIRTH_DATE(resultSet.getInt("birth_date"));
                barangayPolice.setBIRTH_PLACE(resultSet.getString("birth_place"));
                barangayPolice.setGENDER(resultSet.getString("gender"));
                barangayPolice.setHOME_ADD(resultSet.getString("home_add"));
                barangayPolice.setCIVIL_STAT(resultSet.getString("civil_stat"));
                barangayPolice.setNATIONALITY(resultSet.getString("nationality"));
                barangayPolice.setGUARDIAN_NAME(resultSet.getString("guardian"));
                barangayPolice.setRECORDS(resultSet.getString("records"));
                barangayPolice.setOFFENSE(resultSet.getString("offense"));
                barangayPolice.setGUARDIAN_NO(resultSet.getInt("guardian_no"));
                barangayPolice.setTEL_NO(resultSet.getInt("tel_no"));
                barangayPolice.setCONTACT_NO(resultSet.getInt("contact_no"));
                barangayPolice.setNUM_OFF(resultSet.getInt("num_off"));
                barangayPolice.setHEIGHT(resultSet.getInt("height"));
                barangayPolice.setWEIGHT(resultSet.getInt("weight"));
                barangayPolice.setAGE(resultSet.getInt("age"));
                barangayPolice.setPROFILE_PIC(resultSet.getInt("profile_pic"));
             
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataImplement.class.getName()).log(Level.SEVERE, null, ex);
        }
       return barangayPolice;
    }

    @Override
    public List<BarangayPolice> getAllPoliceRecords() throws ServiceException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public BarangayPolice saveRecords(BarangayPolice barangayPolice) throws ServiceException {
       
        PreparedStatement preparedStatement;
        
        try
        {
            if(barangayPolice.getId() == 0)
            {
                String insertsql = ""
                        + "INSERT INTO "
                        + "police_records_tb "
                        + " ("
                        + "first_name,"
                        + "last_name,"
                        + "middle_initial,"
                        + "birth_date,"
                        + "birth_place,"
                        + "gender,"
                        + "home_add,"
                        + "civil_stat,"
                        + "nationality,"
                        + "guardian,"
                        + "records,"
                        + "offense,"
                        + "guardian_no,"
                        + "tel_no,"
                        + "contact_no,"
                        + "num_off,"
                        + "height,"
                        + "weight,"
                        + "age,"
                        + "profile_pic"
                        + ")"
                        + "VALUES "
                        + " (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                preparedStatement = this.getConnection().prepareStatement(insertsql);
                
                preparedStatement.setString(1, barangayPolice.getFIRST_NAME());
                preparedStatement.setString(2, barangayPolice.getLAST_NAME());
                preparedStatement.setString(3, barangayPolice.getMIDDLE_NAME());
                preparedStatement.setString(4, Integer.toString(barangayPolice.getBIRTH_DATE()));
                preparedStatement.setString(5, barangayPolice.getBIRTH_PLACE());
                preparedStatement.setString(6, barangayPolice.getGENDER());
                preparedStatement.setString(7, barangayPolice.getHOME_ADD());
                preparedStatement.setString(8, barangayPolice.getCIVIL_STAT());
                preparedStatement.setString(9, barangayPolice.getNATIONALITY());
                preparedStatement.setString(10, barangayPolice.getGUARDIAN_NAME());
                preparedStatement.setString(11, barangayPolice.getRECORDS());
                preparedStatement.setString(12, barangayPolice.getOFFENSE());
                preparedStatement.setString(13, Integer.toString(barangayPolice.getGUARDIAN_NO()));
                preparedStatement.setString(14, Integer.toString(barangayPolice.getTEL_NO()));
                preparedStatement.setString(15, Integer.toString(barangayPolice.getCONTACT_NO()));
                preparedStatement.setString(16, Integer.toString(barangayPolice.getNUM_OFF()));
                preparedStatement.setString(17, Integer.toString(barangayPolice.getHEIGHT()));
                preparedStatement.setString(18, Integer.toString(barangayPolice.getWEIGHT()));
                preparedStatement.setString(19, Integer.toString(barangayPolice.getAGE()));
                preparedStatement.setString(20, Integer.toString(barangayPolice.getPROFILE_PIC()));
            
                        
                       
            }
            else
            {
                 String updateSql = ""
                        + "UPDATE "
                        + "police_records_tb "
                        + "SET "
                        + "first_name = ?,"
                        + "last_name = ?,"
                        + "middle_initial = ?,"
                        + "birth_date = ?,"
                        + "birth_place = ?,"
                        + "gender = ?,"
                        + "home_add = ?,"
                        + "civil_stat = ?,"
                        + "nationality = ?,"
                        + "guardian = ?,"
                        + "records = ?,"
                        + "offense = ?,"
                        + "guardian_no = ?,"
                        + "tel_no = ?,"
                        + "contact_no = ?,"
                        + "num_off = ?,"
                        + "height = ?,"
                        + "weight = ?,"
                        + "age = ?,"
                        + "profile_pic = ?"
                        + "WHERE"
                        + "id = ?";
                preparedStatement = this.getConnection().prepareStatement(updateSql);
                
                preparedStatement.setString(1, barangayPolice.getFIRST_NAME());
                preparedStatement.setString(2, barangayPolice.getLAST_NAME());
                preparedStatement.setString(3, barangayPolice.getMIDDLE_NAME());
                preparedStatement.setString(4, String.valueOf(barangayPolice.getBIRTH_DATE()));
                preparedStatement.setString(5, barangayPolice.getBIRTH_PLACE());
                preparedStatement.setString(6, barangayPolice.getGENDER());
                preparedStatement.setString(7, barangayPolice.getHOME_ADD());
                preparedStatement.setString(8, barangayPolice.getCIVIL_STAT());
                preparedStatement.setString(9, barangayPolice.getNATIONALITY());
                preparedStatement.setString(10, barangayPolice.getGUARDIAN_NAME());
                preparedStatement.setString(11, barangayPolice.getRECORDS());
                preparedStatement.setString(12, barangayPolice.getOFFENSE());
                preparedStatement.setString(13, String.valueOf(barangayPolice.getGUARDIAN_NO()));
                preparedStatement.setString(14, String.valueOf(barangayPolice.getTEL_NO()));
                preparedStatement.setString(15, String.valueOf(barangayPolice.getCONTACT_NO()));
                preparedStatement.setString(16, String.valueOf(barangayPolice.getNUM_OFF()));
                preparedStatement.setString(17, String.valueOf(barangayPolice.getHEIGHT()));
                preparedStatement.setString(18, String.valueOf(barangayPolice.getWEIGHT()));
                preparedStatement.setString(19, String.valueOf(barangayPolice.getAGE()));
                preparedStatement.setString(20, String.valueOf(barangayPolice.getPROFILE_PIC()));
                preparedStatement.setInt(21, barangayPolice.getId());
                        
                       
            }
            preparedStatement.execute();
        } catch (SQLException ex) {
            System.out.println(ex);
        } 
        return barangayPolice;
    }

    @Override
    public boolean removeRecords(BarangayPolice barangayPolice) throws ServiceException {
        PreparedStatement preparedStatement;
        
        try
        {
            if(barangayPolice.getId() == 0 )
            {
                String deleteSQL = ""
                        + "DELETE FROM"
                        + "police_records_tb"
                        + "WHERE id = ?";
                preparedStatement = this.getConnection().prepareStatement(deleteSQL);
                preparedStatement.setInt(1, barangayPolice.getId());
                preparedStatement.execute();
            }
        } catch (SQLException ex) {
            System.out.println(ex);
            return false;
        }
        return true;
    }
    
    
    
}
